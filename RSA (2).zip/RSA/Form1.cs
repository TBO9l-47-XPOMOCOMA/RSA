﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;
using System.Security.Cryptography;

namespace RSA
{
    public partial class Form1 : Form
    {
        string prev = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            euclid_rb.Checked = true;
        }

        #region checkedChanged
        private void exp_rb_CheckedChanged(object sender, EventArgs e)
        {
            euclidA_textBox.ReadOnly = euclidB_textBox.ReadOnly = mrR_textBox.ReadOnly = true;
            expA_textBox.ReadOnly = expE_textBox.ReadOnly = expN_textBox.ReadOnly = false;
            euclid_button.Enabled = mr_button.Enabled = false;
            exp_button.Enabled = true;
        }
        private void euclid_rb_CheckedChanged(object sender, EventArgs e)
        {
            expA_textBox.ReadOnly = expE_textBox.ReadOnly = expN_textBox.ReadOnly = mrR_textBox.ReadOnly = true;
            euclidA_textBox.ReadOnly = euclidB_textBox.ReadOnly = false;
            exp_button.Enabled = mr_button.Enabled = false;
            euclid_button.Enabled = true;
        }
        private void mr_rb_CheckedChanged(object sender, EventArgs e)
        {
            euclidA_textBox.ReadOnly = euclidB_textBox.ReadOnly = expA_textBox.ReadOnly = expE_textBox.ReadOnly = expN_textBox.ReadOnly = true;
            mrR_textBox.ReadOnly = false;
            euclid_button.Enabled = exp_button.Enabled = false;
            mr_button.Enabled = true;
        }
        #endregion

        #region correct input
        private bool notOnlyNumbers(string text)
        {
            List<char> numbers = new List<char> { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
            int flag = 0;
            for (int i = 0; i < text.Length; i++)
            {
                for (int j = 0; j <= 9; j++)
                {
                    if (text[i] == numbers[j]) flag++;
                }
                if (flag == 0) return true;
                flag = 0;
            }
            return false;
        }
        private void euclidA_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(euclidA_textBox.Text))
            {
                euclidA_textBox.Text = prev;
                euclidA_textBox.SelectionStart = euclidA_textBox.Text.Length;
            }
            else
                prev = euclidA_textBox.Text;
        }
        private void euclidB_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(euclidB_textBox.Text))
            {
                euclidB_textBox.Text = prev;
                euclidB_textBox.SelectionStart = euclidB_textBox.Text.Length;
            }
            else
                prev = euclidB_textBox.Text;
        }
        private void expA_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(expA_textBox.Text))
            {
                expA_textBox.Text = prev;
                expA_textBox.SelectionStart = expA_textBox.Text.Length;
            }
            else
                prev = expA_textBox.Text;
        }
        private void expE_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(expE_textBox.Text))
            {
                expE_textBox.Text = prev;
                expE_textBox.SelectionStart = expE_textBox.Text.Length;
            }
            else
                prev = expE_textBox.Text;
        }
        private void expN_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(expN_textBox.Text))
            {
                expN_textBox.Text = prev;
                expN_textBox.SelectionStart = expN_textBox.Text.Length;
            }
            else
                prev = expN_textBox.Text;
        }

        private void mrR_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(mrR_textBox.Text))
            {
                mrR_textBox.Text = prev;
                mrR_textBox.SelectionStart = mrR_textBox.Text.Length;
            }
            else
                prev = mrR_textBox.Text;
        }
        private void bit_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(bit_textBox.Text))
            {
                bit_textBox.Text = prev;
                bit_textBox.SelectionStart = bit_textBox.Text.Length;
            }
            else
                prev = bit_textBox.Text;
        }

        private void euclidA_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }

        private void euclidB_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }

        private void expA_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }

        private void expE_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }

        private void expN_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }
        private void mrR_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }
        private void bit_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }

        #endregion

        private void euclid_button_Click(object sender, EventArgs e)
        {
            string aText = euclidA_textBox.Text;
            string bText = euclidB_textBox.Text;
            if (aText != "" && bText != "")
            {
                BigInteger a = BigInteger.Parse(euclidA_textBox.Text);
                BigInteger b = BigInteger.Parse(euclidB_textBox.Text);
                BigInteger c = 1;
                List<BigInteger> div_list = new List<BigInteger> { };
                List<BigInteger> x_list = new List<BigInteger> { 0 };
                List<BigInteger> y_list = new List<BigInteger> { 1 };
                bool PUTIN = true;
                bool PREZIDENT_ROSSII = true;
                if (a % b != 0)
                {
                    while (PUTIN == PREZIDENT_ROSSII)
                    {
                        div_list.Add(a / b);
                        c = a % b;
                        a = b;
                        b = c;
                        if (a % b == 0)
                        {
                            div_list.Add(a / b);
                            break;
                        }

                    }
                    gcd_textBox.Text = b.ToString();
                    for (int i = 1; i < div_list.Count; i++)
                    {
                        x_list.Add(y_list[i - 1]);
                        y_list.Add(x_list[i - 1] - y_list[i - 1] * div_list[div_list.Count - i - 1]);
                    }
                }
                else
                {
                    gcd_textBox.Text = b.ToString();
                }
                euclidX_textBox.Text = x_list[x_list.Count - 1].ToString();
                euclidY_textBox.Text = y_list[y_list.Count - 1].ToString();
            }
            else
                MessageBox.Show("Заполните поля");

        }

        private void exp_button_Click(object sender, EventArgs e)
        {
            string a = expA_textBox.Text;
            string eText = expE_textBox.Text;
            string n = expN_textBox.Text;
            if (a != "" && eText != "" && n != "")
            {
                BigInteger a_exp = BigInteger.Parse(expA_textBox.Text);
                BigInteger e_exp = BigInteger.Parse(expE_textBox.Text);
                BigInteger n_exp = BigInteger.Parse(expN_textBox.Text);
                BigInteger cloneE = e_exp;
                BigInteger divisor = 2;
                List<BigInteger> c_exp = new List<BigInteger> { a_exp };
                List<BigInteger> degreeToBinary = new List<BigInteger> { };
                if (n_exp <= 0)
                {
                    MessageBox.Show("Введите N больше нуля");
                }
                else if (e_exp <= 0)
                {
                    MessageBox.Show("Введите E больше нуля");
                }
                else
                {
                    while (true)
                    {
                        BigInteger trash;
                        BigInteger.DivRem(cloneE, divisor, out trash);
                        degreeToBinary.Add(trash);
                        if (cloneE == 1)
                            break;
                        cloneE /= 2;
                    }
                    degreeToBinary.Reverse();
                    for (int i = 1; i < degreeToBinary.Count; i++)
                    {
                        c_exp.Add((c_exp[i - 1] * c_exp[i - 1] * BigInteger.Pow(a_exp, int.Parse(degreeToBinary[i].ToString()))) % n_exp);
                    }
                    expC_textBox.Text = c_exp[c_exp.Count - 1].ToString();
                }
            }
            else
                MessageBox.Show("Заполните поля");
        }

        private bool millerRabin(BigInteger r_mr)
        {
            BigInteger k_mr = (BigInteger)BigInteger.Log(r_mr, 2.0);
            if (r_mr == 2 || r_mr == 3||r_mr==1)
                return true;
            if (r_mr < 2 || r_mr % 2 == 0)
                return false;
            BigInteger t = r_mr - 1;
            BigInteger s = 0;
            while (t % 2 == 0)
            {
                t /= 2;
                s += 1;
            }
            for(BigInteger i = 0; i<k_mr;i++)
            {
                RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
                byte[] forA = new byte[r_mr.ToByteArray().LongLength];
                BigInteger a;
                do
                {
                    rng.GetBytes(forA);
                    a = new BigInteger(forA);
                }
                while (a < 2 || a > r_mr - 2);

                if (r_mr % a == 0)
                    return false;

                BigInteger b = BigInteger.ModPow(a, t, r_mr);
                if (b == 1)
                    continue;
                for (BigInteger j = 1; j < s; j++)
                {
                    b = BigInteger.ModPow(b, 2, r_mr);
                    if (b == r_mr - 1)
                        break;
                }
                if (b != r_mr - 1)
                    return false;

            }
            return true;
        }
        private void mr_button_Click(object sender, EventArgs e)
        {
            if (mrR_textBox.Text != "")
            {
                BigInteger r_mr = BigInteger.Parse(mrR_textBox.Text);
                if (r_mr == 0)
                    MessageBox.Show("Убери ноль, пока я не достала нож.");
                else
                {
                    bool rabiner = millerRabin(r_mr);
                    if (rabiner)
                        mrHmm_textBox.Text = "Вероятно простое";
                    else
                        mrHmm_textBox.Text = "Составное";
                }
            }
            else MessageBox.Show("Вы думаете это смешно? Заполните поля...");
        }

        private void bit_button_Click(object sender, EventArgs e)
        {
            if (bit_textBox.Text == "")
                MessageBox.Show("Кол-во бит введи, не позорься");
            else if (int.Parse(bit_textBox.Text) == 0)
                MessageBox.Show("О да, ломай меня полностью. Шучу. Ноль убери.");
            else if (int.Parse(bit_textBox.Text) > 1024)
            {
                MessageBox.Show("Вы угараете?");
                MessageBox.Show("Я конечно всего лишь программа");
                MessageBox.Show("Но у меня тоже есть чувство собственного достоинства");
                MessageBox.Show("Я отказываюсь выполнять такие большие вычисления");
                MessageBox.Show("Уходите!!!");
                MessageBox.Show("Ну или введите кол-во бит поменьше");
                MessageBox.Show("Пожалуйста...");
            }
            else
            {
                BigInteger bt = BigInteger.Parse(bit_textBox.Text);
                BigInteger result;
                if (bt == 1)
                    result = BigInteger.Pow(2, (int)bt - 1);
                else
                    result = BigInteger.Pow(2, (int)bt - 1) + 1;
                while (!millerRabin(result))
                    result += 2;
                result_textBox.Text = result.ToString();
            }
        }
    }
}
