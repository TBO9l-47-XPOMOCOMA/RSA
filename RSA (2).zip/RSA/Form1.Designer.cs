﻿namespace RSA
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.euclidA_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.euclid_rb = new System.Windows.Forms.RadioButton();
            this.exp_rb = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.euclidB_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.gcd_textBox = new System.Windows.Forms.TextBox();
            this.euclidY_textBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.euclidX_textBox = new System.Windows.Forms.TextBox();
            this.operations_groupBox = new System.Windows.Forms.GroupBox();
            this.expE_textBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.expA_textBox = new System.Windows.Forms.TextBox();
            this.expN_textBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.euclid_button = new System.Windows.Forms.Button();
            this.exp_button = new System.Windows.Forms.Button();
            this.expC_textBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.mr_rb = new System.Windows.Forms.RadioButton();
            this.mrHmm_textBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.mrR_textBox = new System.Windows.Forms.TextBox();
            this.mr_button = new System.Windows.Forms.Button();
            this.bit_button = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.bit_textBox = new System.Windows.Forms.TextBox();
            this.result_textBox = new System.Windows.Forms.TextBox();
            this.operations_groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // euclidA_textBox
            // 
            this.euclidA_textBox.Location = new System.Drawing.Point(31, 12);
            this.euclidA_textBox.Name = "euclidA_textBox";
            this.euclidA_textBox.Size = new System.Drawing.Size(172, 20);
            this.euclidA_textBox.TabIndex = 0;
            this.euclidA_textBox.Click += new System.EventHandler(this.euclidA_textBox_Click);
            this.euclidA_textBox.TextChanged += new System.EventHandler(this.euclidA_textBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(7, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "A";
            // 
            // euclid_rb
            // 
            this.euclid_rb.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.euclid_rb.AutoSize = true;
            this.euclid_rb.Location = new System.Drawing.Point(15, 19);
            this.euclid_rb.Name = "euclid_rb";
            this.euclid_rb.Size = new System.Drawing.Size(54, 17);
            this.euclid_rb.TabIndex = 2;
            this.euclid_rb.TabStop = true;
            this.euclid_rb.Text = "Euclid";
            this.euclid_rb.UseVisualStyleBackColor = true;
            this.euclid_rb.CheckedChanged += new System.EventHandler(this.euclid_rb_CheckedChanged);
            // 
            // exp_rb
            // 
            this.exp_rb.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.exp_rb.AutoSize = true;
            this.exp_rb.Location = new System.Drawing.Point(15, 42);
            this.exp_rb.Name = "exp_rb";
            this.exp_rb.Size = new System.Drawing.Size(95, 17);
            this.exp_rb.TabIndex = 3;
            this.exp_rb.TabStop = true;
            this.exp_rb.Text = "Exponentiation";
            this.exp_rb.UseVisualStyleBackColor = true;
            this.exp_rb.CheckedChanged += new System.EventHandler(this.exp_rb_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(214, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "B";
            // 
            // euclidB_textBox
            // 
            this.euclidB_textBox.Location = new System.Drawing.Point(238, 12);
            this.euclidB_textBox.Name = "euclidB_textBox";
            this.euclidB_textBox.Size = new System.Drawing.Size(159, 20);
            this.euclidB_textBox.TabIndex = 6;
            this.euclidB_textBox.Click += new System.EventHandler(this.euclidB_textBox_Click);
            this.euclidB_textBox.TextChanged += new System.EventHandler(this.euclidB_textBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(403, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "НОД(A,B)";
            // 
            // gcd_textBox
            // 
            this.gcd_textBox.Location = new System.Drawing.Point(483, 11);
            this.gcd_textBox.Name = "gcd_textBox";
            this.gcd_textBox.ReadOnly = true;
            this.gcd_textBox.Size = new System.Drawing.Size(150, 20);
            this.gcd_textBox.TabIndex = 8;
            // 
            // euclidY_textBox
            // 
            this.euclidY_textBox.Location = new System.Drawing.Point(238, 49);
            this.euclidY_textBox.Name = "euclidY_textBox";
            this.euclidY_textBox.ReadOnly = true;
            this.euclidY_textBox.Size = new System.Drawing.Size(159, 20);
            this.euclidY_textBox.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(214, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "Y";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(8, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "X";
            // 
            // euclidX_textBox
            // 
            this.euclidX_textBox.Location = new System.Drawing.Point(32, 49);
            this.euclidX_textBox.Name = "euclidX_textBox";
            this.euclidX_textBox.ReadOnly = true;
            this.euclidX_textBox.Size = new System.Drawing.Size(171, 20);
            this.euclidX_textBox.TabIndex = 9;
            // 
            // operations_groupBox
            // 
            this.operations_groupBox.Controls.Add(this.mr_rb);
            this.operations_groupBox.Controls.Add(this.exp_rb);
            this.operations_groupBox.Controls.Add(this.euclid_rb);
            this.operations_groupBox.Location = new System.Drawing.Point(660, 11);
            this.operations_groupBox.Name = "operations_groupBox";
            this.operations_groupBox.Size = new System.Drawing.Size(128, 98);
            this.operations_groupBox.TabIndex = 13;
            this.operations_groupBox.TabStop = false;
            this.operations_groupBox.Text = "Type of operations";
            // 
            // expE_textBox
            // 
            this.expE_textBox.Location = new System.Drawing.Point(207, 89);
            this.expE_textBox.Name = "expE_textBox";
            this.expE_textBox.ReadOnly = true;
            this.expE_textBox.Size = new System.Drawing.Size(141, 20);
            this.expE_textBox.TabIndex = 17;
            this.expE_textBox.Click += new System.EventHandler(this.expE_textBox_Click);
            this.expE_textBox.TextChanged += new System.EventHandler(this.expE_textBox_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(183, 93);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 16);
            this.label6.TabIndex = 16;
            this.label6.Text = "E";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(8, 93);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 16);
            this.label7.TabIndex = 15;
            this.label7.Text = "A";
            // 
            // expA_textBox
            // 
            this.expA_textBox.Location = new System.Drawing.Point(32, 89);
            this.expA_textBox.Name = "expA_textBox";
            this.expA_textBox.ReadOnly = true;
            this.expA_textBox.Size = new System.Drawing.Size(141, 20);
            this.expA_textBox.TabIndex = 14;
            this.expA_textBox.Click += new System.EventHandler(this.expA_textBox_Click);
            this.expA_textBox.TextChanged += new System.EventHandler(this.expA_textBox_TextChanged);
            // 
            // expN_textBox
            // 
            this.expN_textBox.Location = new System.Drawing.Point(387, 89);
            this.expN_textBox.Name = "expN_textBox";
            this.expN_textBox.ReadOnly = true;
            this.expN_textBox.Size = new System.Drawing.Size(141, 20);
            this.expN_textBox.TabIndex = 19;
            this.expN_textBox.Click += new System.EventHandler(this.expN_textBox_Click);
            this.expN_textBox.TextChanged += new System.EventHandler(this.expN_textBox_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(363, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 16);
            this.label8.TabIndex = 18;
            this.label8.Text = "N";
            // 
            // euclid_button
            // 
            this.euclid_button.Location = new System.Drawing.Point(406, 47);
            this.euclid_button.Name = "euclid_button";
            this.euclid_button.Size = new System.Drawing.Size(227, 23);
            this.euclid_button.TabIndex = 20;
            this.euclid_button.Text = "don\'t push me";
            this.euclid_button.UseVisualStyleBackColor = true;
            this.euclid_button.Click += new System.EventHandler(this.euclid_button_Click);
            // 
            // exp_button
            // 
            this.exp_button.Enabled = false;
            this.exp_button.Location = new System.Drawing.Point(31, 117);
            this.exp_button.Name = "exp_button";
            this.exp_button.Size = new System.Drawing.Size(219, 20);
            this.exp_button.TabIndex = 21;
            this.exp_button.Text = "don\'t push me";
            this.exp_button.UseVisualStyleBackColor = true;
            this.exp_button.Click += new System.EventHandler(this.exp_button_Click);
            // 
            // expC_textBox
            // 
            this.expC_textBox.Location = new System.Drawing.Point(283, 117);
            this.expC_textBox.Name = "expC_textBox";
            this.expC_textBox.ReadOnly = true;
            this.expC_textBox.Size = new System.Drawing.Size(245, 20);
            this.expC_textBox.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(259, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(18, 16);
            this.label9.TabIndex = 22;
            this.label9.Text = "C";
            // 
            // mr_rb
            // 
            this.mr_rb.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.mr_rb.AutoSize = true;
            this.mr_rb.Location = new System.Drawing.Point(15, 65);
            this.mr_rb.Name = "mr_rb";
            this.mr_rb.Size = new System.Drawing.Size(80, 17);
            this.mr_rb.TabIndex = 4;
            this.mr_rb.TabStop = true;
            this.mr_rb.Text = "Miller-Rabin";
            this.mr_rb.UseVisualStyleBackColor = true;
            this.mr_rb.CheckedChanged += new System.EventHandler(this.mr_rb_CheckedChanged);
            // 
            // mrHmm_textBox
            // 
            this.mrHmm_textBox.Location = new System.Drawing.Point(238, 154);
            this.mrHmm_textBox.Name = "mrHmm_textBox";
            this.mrHmm_textBox.ReadOnly = true;
            this.mrHmm_textBox.Size = new System.Drawing.Size(159, 20);
            this.mrHmm_textBox.TabIndex = 27;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(214, 158);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 16);
            this.label10.TabIndex = 26;
            this.label10.Text = "?";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(7, 158);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(19, 16);
            this.label11.TabIndex = 25;
            this.label11.Text = "R";
            // 
            // mrR_textBox
            // 
            this.mrR_textBox.Location = new System.Drawing.Point(31, 154);
            this.mrR_textBox.Name = "mrR_textBox";
            this.mrR_textBox.ReadOnly = true;
            this.mrR_textBox.Size = new System.Drawing.Size(172, 20);
            this.mrR_textBox.TabIndex = 24;
            this.mrR_textBox.Click += new System.EventHandler(this.mrR_textBox_Click);
            this.mrR_textBox.TextChanged += new System.EventHandler(this.mrR_textBox_TextChanged);
            // 
            // mr_button
            // 
            this.mr_button.Enabled = false;
            this.mr_button.Location = new System.Drawing.Point(31, 180);
            this.mr_button.Name = "mr_button";
            this.mr_button.Size = new System.Drawing.Size(219, 24);
            this.mr_button.TabIndex = 28;
            this.mr_button.Text = "don\'t push me";
            this.mr_button.UseVisualStyleBackColor = true;
            this.mr_button.Click += new System.EventHandler(this.mr_button_Click);
            // 
            // bit_button
            // 
            this.bit_button.Location = new System.Drawing.Point(32, 245);
            this.bit_button.Name = "bit_button";
            this.bit_button.Size = new System.Drawing.Size(219, 24);
            this.bit_button.TabIndex = 31;
            this.bit_button.Text = "don\'t push me";
            this.bit_button.UseVisualStyleBackColor = true;
            this.bit_button.Click += new System.EventHandler(this.bit_button_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(7, 219);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 16);
            this.label12.TabIndex = 30;
            this.label12.Text = "BIT";
            // 
            // bit_textBox
            // 
            this.bit_textBox.Location = new System.Drawing.Point(58, 219);
            this.bit_textBox.Name = "bit_textBox";
            this.bit_textBox.Size = new System.Drawing.Size(172, 20);
            this.bit_textBox.TabIndex = 29;
            this.bit_textBox.Click += new System.EventHandler(this.bit_textBox_Click);
            this.bit_textBox.TextChanged += new System.EventHandler(this.bit_textBox_TextChanged);
            // 
            // result_textBox
            // 
            this.result_textBox.Location = new System.Drawing.Point(7, 279);
            this.result_textBox.Multiline = true;
            this.result_textBox.Name = "result_textBox";
            this.result_textBox.Size = new System.Drawing.Size(747, 142);
            this.result_textBox.TabIndex = 32;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.result_textBox);
            this.Controls.Add(this.bit_button);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.bit_textBox);
            this.Controls.Add(this.mr_button);
            this.Controls.Add(this.mrHmm_textBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.mrR_textBox);
            this.Controls.Add(this.expC_textBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.exp_button);
            this.Controls.Add(this.euclid_button);
            this.Controls.Add(this.expN_textBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.expE_textBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.expA_textBox);
            this.Controls.Add(this.operations_groupBox);
            this.Controls.Add(this.euclidY_textBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.euclidX_textBox);
            this.Controls.Add(this.gcd_textBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.euclidB_textBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.euclidA_textBox);
            this.Name = "Form1";
            this.Text = "RSA";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.operations_groupBox.ResumeLayout(false);
            this.operations_groupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox euclidA_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton euclid_rb;
        private System.Windows.Forms.RadioButton exp_rb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox euclidB_textBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox gcd_textBox;
        private System.Windows.Forms.TextBox euclidY_textBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox euclidX_textBox;
        private System.Windows.Forms.GroupBox operations_groupBox;
        private System.Windows.Forms.TextBox expE_textBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox expA_textBox;
        private System.Windows.Forms.TextBox expN_textBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button euclid_button;
        private System.Windows.Forms.Button exp_button;
        private System.Windows.Forms.TextBox expC_textBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton mr_rb;
        private System.Windows.Forms.TextBox mrHmm_textBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox mrR_textBox;
        private System.Windows.Forms.Button mr_button;
        private System.Windows.Forms.Button bit_button;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox bit_textBox;
        private System.Windows.Forms.TextBox result_textBox;
    }
}

