﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;

namespace RSA
{
    public partial class Form1 : Form
    {
        string prev = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            euclid_rb.Checked = true;
        }

        private void exp_rb_CheckedChanged(object sender, EventArgs e)
        {
            if(exp_rb.Checked)
            {
                euclidA_textBox.ReadOnly = euclidB_textBox.ReadOnly = true;
                expA_textBox.ReadOnly = expE_textBox.ReadOnly = expN_textBox.ReadOnly = false;
                euclid_button.Enabled = false;
                exp_button.Enabled = true;
            }
            else
            {
                euclidA_textBox.ReadOnly = euclidB_textBox.ReadOnly = false;
                expA_textBox.ReadOnly = expE_textBox.ReadOnly = expN_textBox.ReadOnly = true;
                euclid_button.Enabled = true;
                exp_button.Enabled = false;
            }
        }



        #region correct input
        private bool notOnlyNumbers(string text)
        {
            List<char> numbers = new List<char> { '0','1','2','3','4','5','6','7','8','9' };
            int flag = 0;
            for (int i = 0; i < text.Length; i++)
            {
                for (int j = 0; j <= 9; j++)
                {
                    if (text[i] == numbers[j]) flag++;
                }
                if (flag == 0) return true;
                flag = 0;
            }
            return false;
        }
        private void euclidA_textBox_TextChanged(object sender, EventArgs e)
        {
            
            if (notOnlyNumbers(euclidA_textBox.Text))
            {
                euclidA_textBox.Text = prev;
                euclidA_textBox.SelectionStart = euclidA_textBox.Text.Length;
            }
            else
                prev = euclidA_textBox.Text;
        }
        private void euclidB_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(euclidB_textBox.Text))
            {
                euclidB_textBox.Text = prev;
                euclidB_textBox.SelectionStart = euclidB_textBox.Text.Length;
            }
            else
                prev = euclidB_textBox.Text;
        }
        private void expA_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(expA_textBox.Text))
            {
                expA_textBox.Text = prev;
                expA_textBox.SelectionStart = expA_textBox.Text.Length;
            }
            else
                prev = expA_textBox.Text;
        }
        private void expE_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(expE_textBox.Text))
            {
                expE_textBox.Text = prev;
                expE_textBox.SelectionStart = expE_textBox.Text.Length;
            }
            else
                prev = expE_textBox.Text;
        }
        private void expN_textBox_TextChanged(object sender, EventArgs e)
        {

            if (notOnlyNumbers(expN_textBox.Text))
            {
                expN_textBox.Text = prev;
                expN_textBox.SelectionStart = expN_textBox.Text.Length;
            }
            else
                prev = expN_textBox.Text;
        }

        private void euclidA_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }

        private void euclidB_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }

        private void expA_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }

        private void expE_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }

        private void expN_textBox_Click(object sender, EventArgs e)
        {
            prev = "";
        }
        #endregion

        private void euclid_button_Click(object sender, EventArgs e)
        {
            BigInteger a = BigInteger.Parse(euclidA_textBox.Text);
            BigInteger b = BigInteger.Parse(euclidB_textBox.Text);
            BigInteger c = 1;
            List<BigInteger> div_list = new List<BigInteger> { };
            List<BigInteger> x_list = new List<BigInteger> { 0};
            List<BigInteger> y_list = new List<BigInteger> { 1};
            bool PUTIN = true;
            bool PREZIDENT_ROSSII = true;
            while(PUTIN==PREZIDENT_ROSSII)
            {
                div_list.Add(a / b);
                c = a%b;
                a = b;
                b = c;
                if (a % b == 0)
                {
                    div_list.Add(a / b);
                    break;
                }
                   
            }
            gcd_textBox.Text = b.ToString();
            for (int i = 1; i < div_list.Count; i++)
            {
                x_list.Add(y_list[i - 1]);
                y_list.Add(x_list[i-1] - y_list[i - 1] * div_list[div_list.Count - i-1]);
            }
            euclidX_textBox.Text = x_list[x_list.Count - 1].ToString();
            euclidY_textBox.Text = y_list[y_list.Count - 1].ToString();
        }

        private void exp_button_Click(object sender, EventArgs e)
        {
            BigInteger a_exp = BigInteger.Parse(expA_textBox.Text);
            BigInteger e_exp = BigInteger.Parse(expE_textBox.Text);
            BigInteger n_exp = BigInteger.Parse(expN_textBox.Text);
            BigInteger cloneE = e_exp;
            BigInteger divisor = 2;
            List<BigInteger> c_exp = new List<BigInteger> { a_exp};
            List<BigInteger> degreeToBinary = new List<BigInteger> { };
            while(true)
            {
                BigInteger trash;
                BigInteger.DivRem(cloneE, divisor, out trash);
                degreeToBinary.Add(trash);
                if(cloneE==1)
                    break;
                cloneE/=2;
            }
            degreeToBinary.Reverse();
            for (int i = 1; i < degreeToBinary.Count; i++)
            {
                c_exp.Add((c_exp[i - 1] * c_exp[i - 1] * BigInteger.Pow(a_exp, int.Parse(degreeToBinary[i].ToString()))) % n_exp);
            }
            expC_textBox.Text = c_exp[c_exp.Count-1].ToString();
        }
    }
}
