﻿namespace RSA
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.euclidA_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.euclid_rb = new System.Windows.Forms.RadioButton();
            this.exp_rb = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.euclidB_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.gcd_textBox = new System.Windows.Forms.TextBox();
            this.euclidY_textBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.euclidX_textBox = new System.Windows.Forms.TextBox();
            this.operations_groupBox = new System.Windows.Forms.GroupBox();
            this.expE_textBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.expA_textBox = new System.Windows.Forms.TextBox();
            this.expN_textBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.euclid_button = new System.Windows.Forms.Button();
            this.exp_button = new System.Windows.Forms.Button();
            this.expC_textBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.operations_groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // euclidA_textBox
            // 
            this.euclidA_textBox.Location = new System.Drawing.Point(53, 20);
            this.euclidA_textBox.Name = "euclidA_textBox";
            this.euclidA_textBox.Size = new System.Drawing.Size(172, 20);
            this.euclidA_textBox.TabIndex = 0;
            this.euclidA_textBox.Click += new System.EventHandler(this.euclidA_textBox_Click);
            this.euclidA_textBox.TextChanged += new System.EventHandler(this.euclidA_textBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(29, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "A";
            // 
            // euclid_rb
            // 
            this.euclid_rb.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.euclid_rb.AutoSize = true;
            this.euclid_rb.Location = new System.Drawing.Point(20, 19);
            this.euclid_rb.Name = "euclid_rb";
            this.euclid_rb.Size = new System.Drawing.Size(54, 17);
            this.euclid_rb.TabIndex = 2;
            this.euclid_rb.TabStop = true;
            this.euclid_rb.Text = "Euclid";
            this.euclid_rb.UseVisualStyleBackColor = true;
            // 
            // exp_rb
            // 
            this.exp_rb.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.exp_rb.AutoSize = true;
            this.exp_rb.Location = new System.Drawing.Point(20, 42);
            this.exp_rb.Name = "exp_rb";
            this.exp_rb.Size = new System.Drawing.Size(95, 17);
            this.exp_rb.TabIndex = 3;
            this.exp_rb.TabStop = true;
            this.exp_rb.Text = "Exponentiation";
            this.exp_rb.UseVisualStyleBackColor = true;
            this.exp_rb.CheckedChanged += new System.EventHandler(this.exp_rb_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(236, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "B";
            // 
            // euclidB_textBox
            // 
            this.euclidB_textBox.Location = new System.Drawing.Point(260, 20);
            this.euclidB_textBox.Name = "euclidB_textBox";
            this.euclidB_textBox.Size = new System.Drawing.Size(159, 20);
            this.euclidB_textBox.TabIndex = 6;
            this.euclidB_textBox.Click += new System.EventHandler(this.euclidB_textBox_Click);
            this.euclidB_textBox.TextChanged += new System.EventHandler(this.euclidB_textBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(425, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "НОД(A,B)";
            // 
            // gcd_textBox
            // 
            this.gcd_textBox.Location = new System.Drawing.Point(505, 23);
            this.gcd_textBox.Name = "gcd_textBox";
            this.gcd_textBox.ReadOnly = true;
            this.gcd_textBox.Size = new System.Drawing.Size(150, 20);
            this.gcd_textBox.TabIndex = 8;
            // 
            // euclidY_textBox
            // 
            this.euclidY_textBox.Location = new System.Drawing.Point(250, 64);
            this.euclidY_textBox.Name = "euclidY_textBox";
            this.euclidY_textBox.ReadOnly = true;
            this.euclidY_textBox.Size = new System.Drawing.Size(220, 20);
            this.euclidY_textBox.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(226, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "Y";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(8, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "X";
            // 
            // euclidX_textBox
            // 
            this.euclidX_textBox.Location = new System.Drawing.Point(32, 49);
            this.euclidX_textBox.Name = "euclidX_textBox";
            this.euclidX_textBox.ReadOnly = true;
            this.euclidX_textBox.Size = new System.Drawing.Size(186, 20);
            this.euclidX_textBox.TabIndex = 9;
            // 
            // operations_groupBox
            // 
            this.operations_groupBox.Controls.Add(this.exp_rb);
            this.operations_groupBox.Controls.Add(this.euclid_rb);
            this.operations_groupBox.Location = new System.Drawing.Point(412, 240);
            this.operations_groupBox.Name = "operations_groupBox";
            this.operations_groupBox.Size = new System.Drawing.Size(128, 80);
            this.operations_groupBox.TabIndex = 13;
            this.operations_groupBox.TabStop = false;
            this.operations_groupBox.Text = "Type of operations";
            // 
            // expE_textBox
            // 
            this.expE_textBox.Location = new System.Drawing.Point(206, 119);
            this.expE_textBox.Name = "expE_textBox";
            this.expE_textBox.ReadOnly = true;
            this.expE_textBox.Size = new System.Drawing.Size(141, 20);
            this.expE_textBox.TabIndex = 17;
            this.expE_textBox.Click += new System.EventHandler(this.expE_textBox_Click);
            this.expE_textBox.TextChanged += new System.EventHandler(this.expE_textBox_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(182, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 16);
            this.label6.TabIndex = 16;
            this.label6.Text = "E";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(8, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 16);
            this.label7.TabIndex = 15;
            this.label7.Text = "A";
            // 
            // expA_textBox
            // 
            this.expA_textBox.Location = new System.Drawing.Point(32, 131);
            this.expA_textBox.Name = "expA_textBox";
            this.expA_textBox.ReadOnly = true;
            this.expA_textBox.Size = new System.Drawing.Size(141, 20);
            this.expA_textBox.TabIndex = 14;
            this.expA_textBox.Click += new System.EventHandler(this.expA_textBox_Click);
            this.expA_textBox.TextChanged += new System.EventHandler(this.expA_textBox_TextChanged);
            // 
            // expN_textBox
            // 
            this.expN_textBox.Location = new System.Drawing.Point(384, 137);
            this.expN_textBox.Name = "expN_textBox";
            this.expN_textBox.ReadOnly = true;
            this.expN_textBox.Size = new System.Drawing.Size(141, 20);
            this.expN_textBox.TabIndex = 19;
            this.expN_textBox.Click += new System.EventHandler(this.expN_textBox_Click);
            this.expN_textBox.TextChanged += new System.EventHandler(this.expN_textBox_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(360, 141);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 16);
            this.label8.TabIndex = 18;
            this.label8.Text = "N";
            // 
            // euclid_button
            // 
            this.euclid_button.Location = new System.Drawing.Point(493, 49);
            this.euclid_button.Name = "euclid_button";
            this.euclid_button.Size = new System.Drawing.Size(283, 23);
            this.euclid_button.TabIndex = 20;
            this.euclid_button.Text = "don\'t push me";
            this.euclid_button.UseVisualStyleBackColor = true;
            this.euclid_button.Click += new System.EventHandler(this.euclid_button_Click);
            // 
            // exp_button
            // 
            this.exp_button.Enabled = false;
            this.exp_button.Location = new System.Drawing.Point(32, 157);
            this.exp_button.Name = "exp_button";
            this.exp_button.Size = new System.Drawing.Size(219, 78);
            this.exp_button.TabIndex = 21;
            this.exp_button.Text = "don\'t push me";
            this.exp_button.UseVisualStyleBackColor = true;
            this.exp_button.Click += new System.EventHandler(this.exp_button_Click);
            // 
            // expC_textBox
            // 
            this.expC_textBox.Location = new System.Drawing.Point(287, 175);
            this.expC_textBox.Name = "expC_textBox";
            this.expC_textBox.ReadOnly = true;
            this.expC_textBox.Size = new System.Drawing.Size(278, 20);
            this.expC_textBox.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(263, 179);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(18, 16);
            this.label9.TabIndex = 22;
            this.label9.Text = "C";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.expC_textBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.exp_button);
            this.Controls.Add(this.euclid_button);
            this.Controls.Add(this.expN_textBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.expE_textBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.expA_textBox);
            this.Controls.Add(this.operations_groupBox);
            this.Controls.Add(this.euclidY_textBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.euclidX_textBox);
            this.Controls.Add(this.gcd_textBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.euclidB_textBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.euclidA_textBox);
            this.Name = "Form1";
            this.Text = "RSA";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.operations_groupBox.ResumeLayout(false);
            this.operations_groupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox euclidA_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton euclid_rb;
        private System.Windows.Forms.RadioButton exp_rb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox euclidB_textBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox gcd_textBox;
        private System.Windows.Forms.TextBox euclidY_textBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox euclidX_textBox;
        private System.Windows.Forms.GroupBox operations_groupBox;
        private System.Windows.Forms.TextBox expE_textBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox expA_textBox;
        private System.Windows.Forms.TextBox expN_textBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button euclid_button;
        private System.Windows.Forms.Button exp_button;
        private System.Windows.Forms.TextBox expC_textBox;
        private System.Windows.Forms.Label label9;
    }
}

